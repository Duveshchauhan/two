import React from 'react'
class Additem extends React.Component {
    constructor(props){
      super(props);
      this.state ={
        productName:"",
        productPrice:0,
      }
    }
    render() { 
        return (
            <form className="row" onSubmit={(e) => {
              e.preventDefault();
              this.props.additem(this.state.productName,(this.state.productPrice))
            }}>
  <div className="form-group mt-3 col-3">
    <label htmlFor="inputName ">Name</label>
    <input
      type="text"
      className="form-control"
      id="inputName"
      aria-describedby="name"
      placeholder="Enter product Name"
      name="productName"
      onChange={(e) => {
              this.setState({productName: e.currentTarget.value});
      }}
      value={this.state.productName} // ** did not understand use of defining the value;
       />
    
  </div>
  <div className="form-group mt-3 ml-50% col-3">
    <label htmlFor="inputPrice">Price</label>
    <input
      type="number"
      className="form-control"
      id="Price "
      placeholder="Enter Price" 
      name='productPrice'
      onChange={(e) => {
  this.setState({productPrice: Number(e.currentTarget.value)});
}}
value={this.state.productPrice}
    />
  </div>
  
  <button type="submit" className="btn btn-primary mt-4 col-2 "  >
    Add
  </button>
</form>

        );
    }
}
 
export default Additem ;