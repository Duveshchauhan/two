import logo from "./logo.svg";
import "./App.css";
import Navbar from "./COMPONENTS/Navbar";
import ProductList from "./COMPONENTS/ProductList.js";
import React, { useState } from "react";
import Footer from "./COMPONENTS/Footer.js";
import Additem from "./COMPONENTS/Additem";

function App() {
  const products = [
    {
      price: 10000,
      name: "Iphone new",
      quantity: 0,
    },
    {
      price: 10000,
      name: "Redmi",
      quantity: 0,
    },
  ];

  let [productList, setProductList] = useState(products);
  let [totalAmount, setTotalAmount] = useState(0);

  const incrementQuantity = (index) => {
    let newProductList = [...productList];
    newProductList[index].quantity++;
    let newtotalAmount = totalAmount;
    newtotalAmount = newtotalAmount + newProductList[index].price;
    setProductList(newProductList);
    setTotalAmount(newtotalAmount);
  };

  const decrementQuantity = (index) => {
    let newProductList = [...productList];
    let newtotalAmount = totalAmount;

    if (newProductList[index].quantity > 0) {
      newProductList[index].quantity--;
      newtotalAmount = newtotalAmount - newProductList[index].price;
    }
    setProductList(newProductList);
    setTotalAmount(newtotalAmount);
  };

  const resetQuantity = () => {
    let newProductList = [...productList];
    newProductList.map((products) => {
      products.quantity = 0;
    })
    setProductList(newProductList);
    setTotalAmount(0);
  };

  const removeQuantity =(index) => {
    let newProductList = [...productList];
    let newtotalAmount=totalAmount;
    // newProductList.splice(index,1); ** the position of slice impacting on removing items**
    newtotalAmount -= newProductList[index].quantity * newProductList[index].price;
    newProductList.splice(index,1); 
    setProductList(newProductList);
    setTotalAmount(newtotalAmount);
  }

  const additem =(name,price) => {
          let newProductList=[...productList];
          newProductList.push({
            price:price,
            name:name,
            quantity:0,
          });
          setProductList(newProductList);
  }

  return (
    <>
      <Navbar />
      <main className="container mt-5">
        <Additem additem={additem}/>
        <ProductList
          productList={productList}
          incrementQuantity={incrementQuantity}
          decrementQuantity={decrementQuantity}
          removeQuantity={removeQuantity}
        />
        <Footer totalAmount={totalAmount} resetQuantity={resetQuantity} />
      </main>
    </>
  );
}

export default App;
